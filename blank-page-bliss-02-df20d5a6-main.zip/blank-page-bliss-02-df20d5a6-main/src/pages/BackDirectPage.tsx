import { useEffect } from "react";

const BackDirectPage = () => {
  // Carrega os scripts da VTurb para ambos os vídeos
  useEffect(() => {
    const scripts = [
      "https://scripts.converteai.net/a7551695-f0bb-4457-a0de-39daa8722731/players/697c3e3f7e3c196b02b696d1/v4/player.js",
      "https://scripts.converteai.net/a7551695-f0bb-4457-a0de-39daa8722731/players/697c3e441fdc17e64dde9ba9/v4/player.js"
    ];

    const scriptElements = scripts.map(src => {
      const s = document.createElement("script");
      s.src = src;
      s.async = true;
      document.head.appendChild(s);
      return s;
    });

    return () => {
      scriptElements.forEach(s => {
        if (document.head.contains(s)) document.head.removeChild(s);
      });
    };
  }, []);

  return (
    <div className="min-h-screen bg-white flex flex-col font-roboto">
      <main className="flex-1 px-4 py-8">
        <div className="max-w-xl mx-auto text-center">
          
          {/* Header Section */}
          <div className="mb-8">
            <h1 className="text-[#c41e3a] text-2xl md:text-3xl font-bold mb-6 leading-tight">
              Before you go, you need to see this...
            </h1>
            <p className="text-[#c41e3a] text-lg md:text-xl font-bold mb-8">
              Dr. Eric Berg has an urgent message for you:
            </p>
          </div>

          {/* Message Section */}
          <div className="space-y-6 text-gray-800 text-base md:text-lg leading-relaxed mb-10">
            <p>I know you're about to leave, but I need to share something crucial...</p>
            <p>But the Natural Protocol is different.</p>
            <p>This simple baking soda trick... restores your erections.</p>
          </div>

          {/* First CTA Button */}
          <div className="mb-12">
            <a href="#" className="inline-block bg-[#5a9c47] text-white font-bold text-base md:text-lg px-8 py-4 rounded-lg hover:bg-[#4a8c37] transition-colors uppercase tracking-wide w-full max-w-md">
              THE PRICE IS A PROBLEM – I WANT A DISCOUNT
            </a>
          </div>

          {/* Testimonial 1 - John */}
          <div className="mb-8">
            <p className="text-gray-800 text-base md:text-lg mb-4">
              See John's testimonial below:
            </p>
            <div className="w-full flex justify-center mb-4">
              <vturb-smartplayer 
                id="vid-697c3e3f7e3c196b02b696d1"
                style={{ display: "block", width: "100%", maxWidth: "400px", borderRadius: "8px", overflow: "hidden" }}
              ></vturb-smartplayer>
            </div>
          </div>

          {/* Testimonial 2 - Gretha (VÍDEO ATUALIZADO) */}
          <div className="mb-10">
            <p className="text-gray-800 text-base md:text-lg mb-4">
              See also Gretha's testimony about her husband:
            </p>
            <div className="w-full flex justify-center mb-4">
              {/* Player da Gretha */}
              <vturb-smartplayer
                id="vid-697c3e441fdc17e64dde9ba9"
                style={{
                  display: "block",
                  width: "100%",
                  maxWidth: "400px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
                }}
              ></vturb-smartplayer>
            </div>
          </div>

          {/* Discount Offer & Final CTA */}
          <div className="mb-10">
            <p className="text-gray-800 text-lg md:text-xl leading-relaxed mb-6 font-bold">
              Just for just $13. 💥
            </p>
            <a href="#" className="inline-block bg-[#5a9c47] text-white font-bold text-lg md:text-xl px-10 py-5 rounded-lg hover:bg-[#4a8c37] transition-all transform hover:scale-105 uppercase tracking-wide w-full max-w-md border-2 border-[#4a8c37]">
              I WANT TO CURE MY IMPOTENCE [$13 TODAY ONLY]
            </a>
          </div>

          {/* Guarantee Section */}
          <div className="mb-8">
            <p className="text-gray-600 text-sm leading-relaxed italic">
              P.S. You're fully protected by our 180-day guarantee.
            </p>
          </div>
        </div>
      </main>

      <footer className="py-6 px-4 border-t border-gray-200">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-gray-500 text-sm">© 2026 All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default BackDirectPage;