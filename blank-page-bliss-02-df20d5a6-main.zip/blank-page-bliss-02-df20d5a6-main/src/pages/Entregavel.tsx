import React, { useState } from "react";

const Entregavel = () => {
  const [form, setForm] = useState({ age: "", weight: "", centimeters: "" });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#f5f5f5] py-8 px-2">
      <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-6 flex flex-col items-center">
        <img
          src="https://i.ibb.co/v6q6gQH4/Gemini-Generated-Image-f01d2nf01d2nf01d.png"
          alt="Protocol Natural Himalayan Logo"
          width={150}
          height={150}
          className="rounded mb-6 mx-auto"
        />
        <div className="w-full bg-black text-white text-center py-4 rounded mb-6">
          <h2 className="text-lg font-bold">Enter your details below to receive your personalized recipe:</h2>
        </div>
        <form className="w-full bg-white text-center p-4 rounded">
          <div className="mb-5">
            <label htmlFor="age" className="block font-semibold mb-2">Your age?</label>
            <input
              type="text"
              id="age"
              name="age"
              value={form.age}
              onChange={handleChange}
              placeholder="Your Age Here"
              className="w-1/2 p-2 border border-gray-300 rounded"
            />
          </div>
          <div className="mb-5">
            <label htmlFor="weight" className="block font-semibold mb-2">Your weight?</label>
            <input
              type="text"
              id="weight"
              name="weight"
              value={form.weight}
              onChange={handleChange}
              placeholder="Your Weight Here"
              className="w-1/2 p-2 border border-gray-300 rounded"
            />
          </div>
          <div className="mb-5">
            <label htmlFor="centimeters" className="block font-semibold mb-2">How many centimeters would you like to gain?</label>
            <input
              type="text"
              id="centimeters"
              name="centimeters"
              value={form.centimeters}
              onChange={handleChange}
              placeholder="Enter Here How Many Inches"
              className="w-1/2 p-2 border border-gray-300 rounded"
            />
          </div>
          <a
            href="http://localhost:3000/entregavel"
            className="inline-block bg-green-600 text-white font-bold py-3 px-6 rounded mt-4 hover:bg-green-700 transition-colors"
          >
            Submit and Receive the Recipe
          </a>
        </form>
      </div>
    </div>
  );
};

export default Entregavel;
