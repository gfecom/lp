import { Link } from "react-router-dom";

const Index = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col font-roboto">
      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="text-center max-w-2xl mx-auto">
          <h2
            style={{ fontFamily: 'Arial, Sans-serif', fontSize: '33px', color: '#FA0303' }}
            className="font-bold mb-8 uppercase tracking-wide"
          >
            WE NEED A CONFIRMATION:
          </h2>
          
          <p className="text-foreground text-lg md:text-xl mb-10">
            Click watch now if you are over 18!
          </p>
          
          <Link
            to="/watch"
            className="inline-block text-white font-bold text-xl md:text-2xl px-12 py-4 rounded-lg hover:opacity-90 transition-opacity uppercase tracking-wider shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            style={{ backgroundColor: '#19EE29' }}
          >
            WATCH NOW!
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
            This site is not affiliated with the Facebook website or Facebook Inc. 
            Additionally, this site is NOT endorsed by Facebook in any manner. 
            Facebook is a trademark of Facebook, Inc. Disclaimer: All information 
            provided is for educational purposes only. Proper due diligence is 
            always recommended before investing in any programs.
          </p>
          
          <p className="text-muted-foreground text-sm">
            2025 © All Rights Reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
