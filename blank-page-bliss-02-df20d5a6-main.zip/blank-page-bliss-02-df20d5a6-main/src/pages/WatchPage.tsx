import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

// --- 1. Declaração de Tipos para o Custom Element ---
declare global {
  namespace JSX {
    interface IntrinsicElements {
      'vturb-smartplayer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>;
    }
  }
}

// --- 2. Imports de Avatares ---
import emilyDavis from "@/assets/avatars/emily-davis.jpeg";
import williamJackson from "@/assets/avatars/william-jackson.jpg";
import ryanTaylor from "@/assets/avatars/ryan-taylor.png";
import adamWilson from "@/assets/avatars/adam-wilson.jpeg";
import gabrielThomas from "@/assets/avatars/gabriel-thomas.jpg";
import augustusHarding from "@/assets/avatars/augustus-harding.jpg";
import roseParker from "@/assets/avatars/rose-parker.jpg";
import teresaMorgan from "@/assets/avatars/teresa-morgan.jpg";
import margaretWilliams from "@/assets/avatars/margaret-williams.png";
import alexanderMiller from "@/assets/avatars/alexander-miller.jpg";
import juliaThompson from "@/assets/avatars/julia-thompson.png";
import mariaEdwards from "@/assets/avatars/maria-edwards.png";
import vanessaSimmons from "@/assets/avatars/vanessa-simmons.jpg";
import sarahJohnson from "@/assets/avatars/sarah-johnson.jpg";
import lauraMitchell from "@/assets/avatars/laura-mitchell.jpg";

// --- 3. Dados dos Comentários Atualizados ---
const comments = [
  {
    name: "Emily Davis",
    avatar: emilyDavis,
    text: "Finally something that really works and gets to the root of the problem. My husband had been suffering for years and Viagra was no longer helping, in fact, it got worse over time. Thanks to this blend, he is satisfying me in bed again. We are relieved; it was slowly killing our relationship. Thank you so much, doctor.",
    time: "2 min"
  },
  {
    name: "William Jackson",
    avatar: williamJackson,
    text: "Finally a quick and to-the-point video that solved my problem.",
    time: "3 min"
  },
  {
    name: "Ryan Taylor",
    avatar: ryanTaylor,
    text: "Does this work? I've spent so much money on things that don't work.",
    time: "5 min"
  },
  {
    name: "Adam Wilson",
    avatar: adamWilson,
    text: "I'm 53 and my wife is 31. I used to be so embarrassed because I couldn't satisfy her even with the blue pill. And I confess, I was afraid she'd leave me. But thanks to this drink that Dr. Robert recommended, I've been taking it every day for a month and my wife is amazed with me, asking what I'm doing haha",
    time: "8 min"
  },
  {
    name: "Gabriel Thomas",
    avatar: gabrielThomas,
    text: "I was also doubtful, I didn't believe in anything before experiencing it myself. But as it's a urologist doctor recommending it… I decided to try and it was the only method that worked for me, my wife is impressed haha VERY GOOD",
    time: "14 min"
  },
  {
    name: "Augustus Harding",
    avatar: augustusHarding,
    text: "I just wish I had found this video before being cheated on by my girlfriend haha. At least now I'm not embarrassed being single! 😎",
    time: "10 min"
  },
  {
    name: "Rose Parker",
    avatar: roseParker,
    text: "I'm embarrassed to talk haha, but I showed it to my husband and I confess that I already see the difference🤭",
    time: "5 min"
  },
  {
    name: "Teresa Morgan",
    avatar: teresaMorgan,
    text: "It's incredible how fast the effects are. I showed the video to my husband last week, today is his third day taking it and our nights have been intense and amazing 😍",
    time: "10 min"
  },
  {
    name: "Margaret Williams",
    avatar: margaretWilliams,
    text: "Now that my husband has overcome that problem, our relationship is much better, things have heated up between us again. This mix from the video works wonders🫣",
    time: "16 min"
  },
  {
    name: "Alexander Miller",
    avatar: alexanderMiller,
    text: "This is incredible.. it really works, thanks to this I stopped using tadalafil and viagra which nearly gave me a heart attack once when I overused it. This mix is not only easy to make but natural and poses no risks, and it's much more potent!🫣",
    time: "35 min"
  },
  {
    name: "Julia Thompson",
    avatar: juliaThompson,
    text: "Ladies who are going to show this to their partners and have incredible nights, comment 😏🤭👇",
    time: "16 min"
  },
  {
    name: "Maria Edwards",
    avatar: mariaEdwards,
    text: "My husband just started, we're excited. 🫣",
    time: "10 min"
  },
  {
    name: "Vanessa Simmons",
    avatar: vanessaSimmons,
    text: "This is my dream 😅",
    time: "10 min"
  },
  {
    name: "Sarah Johnson",
    avatar: sarahJohnson,
    text: "I already showed it to him, he started 15 days ago and you have no idea how good it is! We're in our best phase in 5 years of marriage. Thanks to this recipe.",
    time: "10 min"
  },
  {
    name: "Laura Mitchell",
    avatar: lauraMitchell,
    text: "This is wonderful. It worked a miracle here at home.😅",
    time: "10 min"
  }
];

const WatchPage = () => {
  const navigate = useNavigate();

  // --- 4. Carregamento do Script do Vturb ---
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://scripts.converteai.net/a7551695-f0bb-4457-a0de-39daa8722731/players/697c32847e3c196b02b6867e/v4/player.js";
    script.async = true;
    document.head.appendChild(script);

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
      // Redireciona ao sair da página (Back-redirect logic)
      navigate('/back-direct', { replace: true });
    };
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background flex flex-col font-roboto">
      <main className="flex-1 px-4 py-8">
        <div className="max-w-3xl mx-auto">
          
          {/* Header Section */}
          <div className="mb-6">
            <h2 className="text-foreground text-center text-lg md:text-xl font-medium mb-4">
              Watch until the end to access
            </h2>
            
            {/* Vturb Player Container */}
            <div className="mb-4 flex justify-center">
              <div id="converteai-player-container" style={{ width: '100%', maxWidth: '640px' }}>
                <vturb-smartplayer 
                  id="vid-697c32847e3c196b02b6867e" 
                  style={{ display: 'block', margin: '0 auto', width: '100%' }}
                ></vturb-smartplayer>
              </div>
            </div>
          </div>

          {/* Sound Notice */}
          <div className="text-center mb-8">
            <p className="text-muted-foreground text-sm flex items-center justify-center gap-2">
              <span className="text-lg">🔊</span>
              Make sure your sound is turned on!
            </p>
          </div>

          {/* Divider */}
          <div className="border-t border-border my-8"></div>

          {/* Comments Section - Estilo "Facebook" UI */}
          <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
            <h3 className="text-gray-900 font-bold text-lg mb-6 border-b border-gray-200 pb-3">
              157 Comments
            </h3>
            
            <div className="space-y-6">
              {comments.map((comment, index) => (
                <div key={index} className="flex gap-3 border-b border-gray-100 pb-4 last:border-b-0">
                  {/* Avatar */}
                  <div className="w-12 h-12 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden">
                    <img 
                      src={comment.avatar} 
                      alt={comment.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Comment Body */}
                  <div className="flex-1">
                    <p className="text-blue-600 font-bold text-sm mb-1">
                      {comment.name}:
                    </p>
                    <p className="text-gray-700 text-sm leading-relaxed mb-2">
                      {comment.text}
                    </p>
                    <div className="flex items-center gap-1 text-xs text-blue-500">
                      <span className="hover:underline cursor-pointer">Comment</span>
                      <span className="text-gray-400">·</span>
                      <span className="hover:underline cursor-pointer">Like</span>
                      <span className="text-gray-400">·</span>
                      <span className="hover:underline cursor-pointer">Share</span>
                      <span className="text-gray-400">·</span>
                      <span className="text-gray-500">{comment.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Login Notice */}
            <div className="text-center mt-6 pt-4 border-t border-gray-200">
              <p className="text-gray-500 text-sm">You must log in to leave a comment.</p>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
};

export default WatchPage;